﻿using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using VRC.Udon;

/// <summary>
/// AIに分子情報を送信し、結合種類を判定してChemElementSpawnerに返す
/// </summary>
public class AIRequestSender : UdonSharpBehaviour
{
    private ChemElementSpawner currentSpawner;

    /// <summary>
    /// ExperimentOrchestrator から呼ばれるエントリーポイント
    /// </summary>
    public void Run(string moleculeJson, ChemElementSpawner spawner)
    {
        SendMoleculeRequest(moleculeJson, spawner);
    }

    /// <summary>
    /// Spawnerから呼ばれる: JSONをAIに送信
    /// </summary>
    public void SendMoleculeRequest(string moleculeJson, ChemElementSpawner spawner)
    {
        currentSpawner = spawner;

        // 実際はここで外部AIと通信する
        Debug.Log("[AIRequestSender] Molecule JSON: " + moleculeJson);

        // --- 仮のAI応答（デモ用） ---
        // 例: H2Oなら [0-1 単結合] [0-2 単結合]
        // 将来はここをHTTPリクエストや別のAI処理に置き換える
        if (moleculeJson.Contains("\"H\"") && moleculeJson.Contains("\"O\""))
        {
            ApplyBondResult(0, 1, 1); // 単結合
            ApplyBondResult(0, 2, 1); // 単結合
        }
        else if (moleculeJson.Contains("\"C\"") && moleculeJson.Contains("\"O\""))
        {
            ApplyBondResult(0, 1, 2); // C=O 二重結合
        }
        else
        {
            // 未知な分子 → とりあえずランダムな結合
            if (moleculeJson.Contains("atoms"))
            {
                ApplyBondResult(0, 1, Random.Range(1, 4));
            }
        }
    }

    /// <summary>
    /// AIの応答を解析してSpawnerに反映
    /// </summary>
    private void ApplyBondResult(int atomA, int atomB, int bondType)
    {
        if (currentSpawner != null)
        {
            currentSpawner.ApplyBondUpdate(atomA, atomB, bondType);
        }
    }
}
